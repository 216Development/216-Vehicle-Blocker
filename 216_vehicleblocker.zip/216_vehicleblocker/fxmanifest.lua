
fx_version 'bodacious'
game 'gta5'
author '216 Development'

client_script 'client.lua'
